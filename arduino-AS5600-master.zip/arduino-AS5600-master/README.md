# AS5600
AS5600 12-bits Absolute Magnetic Encoder
